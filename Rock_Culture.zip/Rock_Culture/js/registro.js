const $btnSingIn=document.querySelector('.sing-in-btn'),
      $btnSingUp = document.querySelector('.sing-up-btn'),
      $SingUp = document.querySelector('.sing-up'),
      $SingIn = document.querySelector('.sing-in');

document.addEventListener('click', e =>{
    if (e.target === $btnSingIn || e.target === $btnSingUp){
        $SingIn.classList.toggle('active');
        $SingUp.classList.toggle('active')
    }
    
});