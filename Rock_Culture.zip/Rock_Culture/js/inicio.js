
// Ejecucuion del reproductor del home
let audioNirvana = document.getElementById("audioNirvana");
let botonNirvana = document.getElementById("botonNirvana");

let audioQueen = document.getElementById('audioQueen')
let botonQueen = document.getElementById('botonQueen')

let audioArticsMonkeys = document.getElementById('audioArticsMonkeys')
let botonArticsMonkeys = document.getElementById('botonArticsMonkeys')

  // Mostrar los resultados
  resultsContainer.innerHTML = '';
  if (filteredProducts.length > 0) {
    filteredProducts.forEach(function(product) {
      let productElement = document.createElement('div');
      productElement.textContent = product.name + ' - $' + product.price;
      resultsContainer.appendChild(productElement);
    });
  } else {
    resultsContainer.textContent = 'No se encontraron resultados';
  }

// definir funcion para el reproductor del home

function audio1Nirvana() {
  if (audioNirvana.paused) {
    audioNirvana.play();
    botonNirvana.innerHTML = "Pause";
  } else {
    audioNirvana.pause();
    botonNirvana.innerHTML = "Play";
  }
}

function audio1Queen() {
    if (audioQueen.paused) {
        audioQueen.play();
        botonQueen.innerHTML = "Pause";
    } else {
        audioQueen.pause();
      botonQueen.innerHTML = "Play";
    }
  }

function audio1ArticsMonkeys() {
  if (audioArticsMonkeys.paused) {
        audioArticsMonkeys.play();
        botonArticsMonkeys.innerHTML = "Pause";
  } else {
      audioArticsMonkeys.pause();
      botonArticsMonkeys.innerHTML = "Play";
    }
  }

