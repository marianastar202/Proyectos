#Documentacion de la tienda de rock

#Esta tienda de rock es un sitio web interactivo que 
permite vender y comprar productos referentes al rock en linea.
Esta construido por HTML, CSS, y JAVASCRIPT para brindar una experiencia
al usuario funcional.

#Estructura de archivos

1. Inicio.html: Pagina principal de nuestro sitio web
css/: directorio ue contiene archivos css para dar estilo al sitio

2. Style:directorio  que contiene los estilos globales del sitio.css
    
3. js/: directorio que contiene archivos javascript utilizados para agregar
 interactividad al sitio

4. img/: directorio que contiene las imagenes del sitio web